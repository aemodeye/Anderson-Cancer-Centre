README File for PCA and Logistics Regression on Breast Cancer Dataset

Description
This project aims to analyze the breast cancer dataset using Principal Component ANalysis (PCA) for dimensionality reduction and applies logistics regression for classification. The goal is to identify essential variables and evaluate the model's performance in predicting whether tumors are malignant or benign.

Installations

To run this project successfully, you will need to have Python 3.x installed along with the following libraries:
Numpy
Pandas
scikit-learn
Matplotlib

Usage

1. Clone the repository or download the files
2. Navigate to the project directory
3. Run the Python script
4 The script will execute the following:
- load the breast cancer dataset. Describing it and giving the first 5 rows and their details.
- perfoem PCA to reduce the dataset to 2 components.
- Visualize the PCA results in a scatter plot.
- Train a logistic regression model on the PCA-reduced data.
- Output evaluation metrics including a confusion matrix and classification report.

Results

PCA Visualization
We see that the plot displays two principal components (PC1 and PC2) of the breast cancer dataset. The data points are color-coded based on the tumor classification whether they are maglinant or benign.